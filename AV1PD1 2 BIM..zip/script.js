var fundo = document.getElementById("fundo");
var body = document.querySelector("body");
fundo.addEventListener("click", ()=>{
fundo.classList.toggle("preto")
body.classList.toggle("preto")
})